package es.cursojava.examen.parteUno.interfaces;

public interface Curso {

	String obtenerNombre();
	String obtenerCodigo();
	int obtenerCupoDisponible();
}
